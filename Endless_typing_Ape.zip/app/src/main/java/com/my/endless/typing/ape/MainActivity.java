package com.my.endless.typing.ape;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double generate_num = 0;
	private String generated_letter = "";
	private double trys = 0;
	private String letters_showed = "";
	private double word_lenght = 0;
	private double y = 0;
	private double total = 0;
	private String last_generated_letter = "";
	private double find_words = 0;
	private double json_words_n = 0;
	private String pre_last_generated_letter = "";
	private boolean timer_active = false;
	
	private ArrayList<String> strlist = new ArrayList<>();
	
	private LinearLayout linear2;
	private EditText edittext_find_word;
	private LinearLayout linear_output_background;
	private LinearLayout linear_finding_words_background;
	private LinearLayout linear3;
	private TextView textview_output;
	private TextView textview_find_words;
	private LinearLayout linear4;
	private TextView textview_trys;
	private TextView textview2;
	private ScrollView vscroll1;
	private LinearLayout linear5;
	private TextView textview_finding_words;
	private Button button_start;
	private Button button_stop;
	
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		edittext_find_word = findViewById(R.id.edittext_find_word);
		linear_output_background = findViewById(R.id.linear_output_background);
		linear_finding_words_background = findViewById(R.id.linear_finding_words_background);
		linear3 = findViewById(R.id.linear3);
		textview_output = findViewById(R.id.textview_output);
		textview_find_words = findViewById(R.id.textview_find_words);
		linear4 = findViewById(R.id.linear4);
		textview_trys = findViewById(R.id.textview_trys);
		textview2 = findViewById(R.id.textview2);
		vscroll1 = findViewById(R.id.vscroll1);
		linear5 = findViewById(R.id.linear5);
		textview_finding_words = findViewById(R.id.textview_finding_words);
		button_start = findViewById(R.id.button_start);
		button_stop = findViewById(R.id.button_stop);
		
		edittext_find_word.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((EditText)edittext_find_word).selectAll();
			}
		});
		
		button_start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_find_word.getText().toString().length() > 0) {
					edittext_find_word.setText(edittext_find_word.getText().toString().toUpperCase());
					textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
					strlist.clear();
					textview_finding_words.setText("");
					edittext_find_word.setTextColor(0xFFEF5350);
					edittext_find_word.setEnabled(false);
					button_start.setVisibility(View.GONE);
					button_stop.setVisibility(View.VISIBLE);
					timer_active = true;
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (letters_showed.contains(edittext_find_word.getText().toString())) {
										t.cancel();
										SpannableString spannableString = new SpannableString(letters_showed);
										android.text.style.BackgroundColorSpan bgSpan = new android.text.style.BackgroundColorSpan(0xFF00E676);
										word_lenght = edittext_find_word.getText().toString().length();
										y = 0;
										for(int _repeat16 = 0; _repeat16 < (int)((1 + (letters_showed.length() - word_lenght))); _repeat16++) {
												if (letters_showed.substring((int)(y), (int)(y + word_lenght)).equals(edittext_find_word.getText().toString())) {
													y++;
											}
											else {
													y++;
											}
										}
										int x = 0;
										int n = letters_showed.indexOf(edittext_find_word.getText().toString(), x);
										x = n+1;
										spannableString.setSpan(android.text.style.CharacterStyle.wrap(bgSpan), n, n + edittext_find_word.getText().length(), 0);
										textview_output.setText(spannableString);
										trys = 0;
										find_words = 0;
										pre_last_generated_letter = "";
										last_generated_letter = "";
										letters_showed = "";
										edittext_find_word.setTextColor(0xFF66BB6A);
										edittext_find_word.setEnabled(true);
										button_start.setVisibility(View.VISIBLE);
										button_stop.setVisibility(View.GONE);
									}
									else {
										pre_last_generated_letter = last_generated_letter;
										last_generated_letter = generated_letter;
										_generate();
										_word_check();
										letters_showed = letters_showed.concat(generated_letter);
										if (letters_showed.length() > 330) {
											letters_showed = letters_showed.substring(1);
											textview_output.setText(letters_showed);
										}
										else {
											textview_output.setText(letters_showed);
										}
										trys++;
										textview_trys.setText("Getippte Zeichen: ".concat(String.valueOf((long)(trys))));
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(t, (int)(0), (int)(50));
				}
			}
		});
		
		button_stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				t.cancel();
				trys = 0;
				find_words = 0;
				letters_showed = "";
				last_generated_letter = "";
				edittext_find_word.setEnabled(true);
				button_start.setVisibility(View.VISIBLE);
				button_stop.setVisibility(View.GONE);
			}
		});
	}
	
	private void initializeLogic() {
		textview_trys.setText("Getippte Zeichen: ".concat(String.valueOf((long)(trys))));
		textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		textview_output.setText(letters_showed);
		textview_finding_words.setText("");
		button_stop.setVisibility(View.GONE);
		textview2.setPaintFlags(textview2.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		moveTaskToBack(true);
	}
	
	@Override
	public void onBackPressed() {
		if (timer_active) {
			t.cancel();
		}
		finish();
	}
	public void _generate() {
		generate_num = SketchwareUtil.getRandom((int)(1), (int)(26));
		if (generate_num == 1) {
			generated_letter = "A";
		}
		if (generate_num == 2) {
			generated_letter = "B";
		}
		if (generate_num == 3) {
			generated_letter = "C";
		}
		if (generate_num == 4) {
			generated_letter = "D";
		}
		if (generate_num == 5) {
			generated_letter = "E";
		}
		if (generate_num == 6) {
			generated_letter = "F";
		}
		if (generate_num == 7) {
			generated_letter = "G";
		}
		if (generate_num == 8) {
			generated_letter = "H";
		}
		if (generate_num == 9) {
			generated_letter = "I";
		}
		if (generate_num == 10) {
			generated_letter = "J";
		}
		if (generate_num == 11) {
			generated_letter = "K";
		}
		if (generate_num == 12) {
			generated_letter = "L";
		}
		if (generate_num == 13) {
			generated_letter = "M";
		}
		if (generate_num == 14) {
			generated_letter = "N";
		}
		if (generate_num == 15) {
			generated_letter = "O";
		}
		if (generate_num == 16) {
			generated_letter = "P";
		}
		if (generate_num == 17) {
			generated_letter = "Q";
		}
		if (generate_num == 18) {
			generated_letter = "R";
		}
		if (generate_num == 19) {
			generated_letter = "S";
		}
		if (generate_num == 20) {
			generated_letter = "T";
		}
		if (generate_num == 21) {
			generated_letter = "U";
		}
		if (generate_num == 22) {
			generated_letter = "V";
		}
		if (generate_num == 23) {
			generated_letter = "W";
		}
		if (generate_num == 24) {
			generated_letter = "X";
		}
		if (generate_num == 25) {
			generated_letter = "Y";
		}
		if (generate_num == 26) {
			generated_letter = "Z";
		}
	}
	
	
	public void _word_check() {
		if (last_generated_letter.concat(generated_letter).equals("AB")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("AD")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("AI")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("AM")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("AN")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("AU")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("BF")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("BH")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("BI")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("CA")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("CD")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("CH")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("CM")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (last_generated_letter.concat(generated_letter).equals("CO")) {
			strlist.add(last_generated_letter.concat(generated_letter));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
		}
		if (pre_last_generated_letter.concat(last_generated_letter.concat(generated_letter)).equals("AMA")) {
			strlist.add(pre_last_generated_letter.concat(last_generated_letter.concat(generated_letter)));
			textview_finding_words.setText(textview_finding_words.getText().toString().concat(strlist.get((int)(strlist.size() - 1)).concat("\n")));
			find_words++;
			textview_find_words.setText("Getippte Wörter: ".concat(String.valueOf((long)(find_words))));
			SketchwareUtil.showMessage(getApplicationContext(), "AMA");
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}